---
name: Feature request
about: Suggest an idea for CookieMonster
title: ''
labels: Enhancement
assignees: ''

---

**Describe the function you'd like to see added to CookieMonster**
A clear and concise description of what you want to happen.

**Additional files**
Add any other files such as save files or screenshots about the feature request here.
