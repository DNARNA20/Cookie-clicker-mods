/** All variables used by simulation functions */

export let SimObjects = []; // eslint-disable-line prefer-const
export let SimUpgrades = []; // eslint-disable-line prefer-const
export let SimAchievements = []; // eslint-disable-line prefer-const
export let SimBuildingsOwned;
export let SimUpgradesOwned;
export let SimPledges;
export let SimAchievementsOwned;
export let SimHeavenlyPower;
export let SimPrestige;
export let SimDragonAura;
export let SimDragonAura2;
export let SimGod1;
export let SimGod2;
export let SimGod3;
export let SimDoSims;
export let SimEffs;
export let SimCookiesPs;
export let SimCookiesPsRaw;
