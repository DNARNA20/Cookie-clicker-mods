javascript: (function () {
  Game.LoadMod("https://icehawk78.github.io/FrozenCookies/frozen_cookies.js");
})();
